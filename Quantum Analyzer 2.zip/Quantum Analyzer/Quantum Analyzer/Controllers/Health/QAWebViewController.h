//
//  QAWebViewController.h
//  Quantum Analyzer
//
//  Created by 宋冲冲 on 2016/12/7.
//  Copyright © 2016年 宋冲冲. All rights reserved.
//

#import "QABaseViewController.h"

@interface QAWebViewController : QABaseViewController

@property (nonatomic, copy) NSString *fileName;

@end
