//
//  QAHealthViewController.m
//  Quantum Analyzer
//
//  Created by 宋冲冲 on 2016/12/4.
//  Copyright © 2016年 宋冲冲. All rights reserved.
//

#import "QAHealthViewController.h"
#import "QAHealthTableViewCell.h"
#import "QAWebViewController.h"

@interface QAHealthViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSArray *sourceArray;
@end

@implementation QAHealthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initTitleLabel:@"健康评估"];
    _sourceArray = [NSArray arrayWithObjects:@"量子弱磁综合报告单",@"心脑血管检测报告",@"胃肠功能检测报告",@"肝功能检测报告",@"胆功能检测报告",@"胰腺功能检测报告",@"肾脏功能检测报告",@"肺功能检测报告",@"脑神经检测报告",@"骨病检测报告",@"骨密度检测报告",@"风湿骨病检测报告",@"骨生长指数检测报告",@"血糖检测报告",@"微量元素检测报告",@"维生素检测报告",@"氨基酸检测报告",@"辅酶检测报告",@"内分泌系统检测报告",@"免疫系统检测报告",@"人体毒素检测报告",@"重金属检测报告",@"基本体质检测报告",@"过敏检测报告",@"皮肤检测报告",@"眼部检测报告",@"大肠检测检测报告",@"甲状腺检测报告",@"血脂检测报告",@"精子和精液检测报告",@"前列腺检测报告",@"男性性功能检测报告",@"经络检测报告",@"肥胖症检测报告",@"胶原蛋白检测报告",@"脉搏与脑血管检测报告",@"人体成分检测报告", nil];
    // Do any additional setup after loading the view from its nib.
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, DScreenWidth, DScreenHeight) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableFooterView = [UIView new];
    [self.view addSubview:tableView];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 40;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _sourceArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"cell";
    QAHealthTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (!cell) {
        cell = [[QAHealthTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    cell.textLabel.text = _sourceArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    QAWebViewController *webViewVC = [[QAWebViewController alloc] init];
    webViewVC.fileName = _sourceArray[indexPath.row];
    [self.navigationController pushViewController:webViewVC animated:YES];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
