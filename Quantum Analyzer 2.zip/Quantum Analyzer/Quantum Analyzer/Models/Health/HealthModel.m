//
//  HealthModel.m
//  Quantum Analyzer
//
//  Created by 宋冲冲 on 2016/12/9.
//  Copyright © 2016年 宋冲冲. All rights reserved.
//

#import "HealthModel.h"

@implementation HealthModel

@end
