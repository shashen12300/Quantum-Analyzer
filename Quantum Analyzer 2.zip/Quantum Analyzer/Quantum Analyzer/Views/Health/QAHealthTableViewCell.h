//
//  QAHealthTableViewCell.h
//  Quantum Analyzer
//
//  Created by 宋冲冲 on 2016/12/7.
//  Copyright © 2016年 宋冲冲. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QAHealthTableViewCell : UITableViewCell

@end
